package com.cybage.clientmgmt.service.home;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.clientmgmt.dao.home.HomeDaoInterface;
import com.cybage.clientmgmt.models.login.Role;
import com.cybage.clientmgmt.models.login.User;

@Service
public class HomeServiceInterfaceImpl implements HomeServiceInterface{

	@Autowired
	private HomeDaoInterface dao;
	@Override
	public String registerUser(User user) {
	
		return dao.registerUser(user);
	}

	@Override
	public String registerRole(Role role) {
		// TODO Auto-generated method stub
		return dao.registerRole(role);
	}

}
