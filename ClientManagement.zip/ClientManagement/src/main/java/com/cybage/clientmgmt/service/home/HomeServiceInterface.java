package com.cybage.clientmgmt.service.home;

import com.cybage.clientmgmt.models.login.Role;
import com.cybage.clientmgmt.models.login.User;

public interface HomeServiceInterface {

	String registerUser(User user);
	String registerRole(Role role);
	
	
}
