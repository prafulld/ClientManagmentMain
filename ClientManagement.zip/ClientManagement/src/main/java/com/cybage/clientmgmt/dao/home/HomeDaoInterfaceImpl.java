package com.cybage.clientmgmt.dao.home;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.clientmgmt.models.login.Role;
import com.cybage.clientmgmt.models.login.User;
@Repository
@Transactional
public class HomeDaoInterfaceImpl implements HomeDaoInterface{

	@Autowired
	private SessionFactory session;
	
	@Override
	public String registerUser(User user) {
Integer id = (Integer) session.getCurrentSession().save(user);
		
		System.out.println(id);
		
		if(id == null)
			return "fail";
		return "success";
		
	}

	@Override
	public String registerRole(Role role) {
		Integer id=(Integer)session.getCurrentSession().save(role);
		if(id == null)
			return "fail";
		return "success";
		
	}

}
