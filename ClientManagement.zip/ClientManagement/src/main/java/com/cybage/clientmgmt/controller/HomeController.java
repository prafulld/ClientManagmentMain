package com.cybage.clientmgmt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.cybage.clientmgmt.models.login.User;
import com.cybage.clientmgmt.service.home.HomeServiceInterface;


@RestController
@RequestMapping("/main")
public class HomeController {
	
	@Autowired
	HomeServiceInterface service;
	
	public HomeController() {
		System.out.println("Home Controller Ctor");
	}
	
	  @RequestMapping(value = "/registerUser/", method = RequestMethod.POST)
	    public ResponseEntity<Void> createUser(@RequestBody User user,    UriComponentsBuilder ucBuilder) {
	        System.out.println("Creating User " + user.getFname());
	 
	        
	 
	        service.registerUser(user);
	 
	        HttpHeaders headers = new HttpHeaders();
	       	return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	    }
	
	/*@RequestMapping(value="/next")
	public String showNextPage()
	{
		System.out.println("In showNextPage");
		return "home";
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String showRegisterForm(@ModelAttribute("user") User user)
	{
		System.out.println("IN showRegisterForm");
		return "register";
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String processRegisterForm(@ModelAttribute User user, ModelMap model)
	{
		
		String status = service.registerUser(user);
		model.addAttribute("status", status);
		return "home";
	}
	
	@RequestMapping(value = "/get", method = RequestMethod.GET)
	public String getUser(ModelMap model)
	{
		model.addAttribute("ad", service.getUser(8));
		return "home";
	}*/
}
