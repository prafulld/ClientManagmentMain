package com.cybage.clientmgmt.models.utils;

import java.util.UUID;

public class Util 
{
	public static String getUUID()
	{
		return UUID.randomUUID().toString();
	}
}
